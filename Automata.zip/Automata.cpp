﻿// Automata.cpp: 定义控制台应用程序的入口点。
//


#include <cstdlib>
#include <iostream>

using namespace std;

void AutomataTest();  // AutomataTest.cpp

int main()
{
	AutomataTest();
	/*system("pause");*/ //pause 命令在Linux不可用
	cin.get();
	return 0;
}


